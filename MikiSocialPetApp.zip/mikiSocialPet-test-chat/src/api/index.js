import {create} from 'apisauce';

export const api = create({
  baseURL: `http://obnd.me/`,
});